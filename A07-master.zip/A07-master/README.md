# A07

## Exercício A7

Codificação retirada do github https://github.com/kenjdavidson/react-native-bluetooth-classic/tree/master/BluetoothClassicExample
