import { StyleSheet, TouchableOpacity, View } from 'react-native'
import React, { useState, useEffect } from 'react';
import { requestPermissionsAsync, getCurrentPositionAsync } from 'expo-location'
import MapView from 'react-native-maps';
import { MaterialIcons } from '@expo/vector-icons'

export default function App() {
  // Guarda a localizacao atual
  const [currentRegion, setCurrentRegion] = useState(null);

  // Guarda o tipo de mapa atual
  const [mapType, setMapType] = useState('satellite');

  // Executa ao abrir o app para buscar a localizacao
  useEffect(() => {

    async function loadInitialPosition() {

      // Requisita permissao para acessar localizacao do usuario
      const { granted } = await requestPermissionsAsync();

      if (granted) {

        // Busca a localizacao
        const { coords } = await getCurrentPositionAsync({
          enableHighAccuracy: true,
        });

        const { latitude, longitude } = coords;

        // Salva a localizacao atual
        setCurrentRegion({
          latitude,
          longitude,
          latitudeDelta: 0.04,
          longitudeDelta: 0.04,
        });
      }
    }

    loadInitialPosition();
  }, []);

  // Evento para atualizar o valor da posicao atual quando o usuario mexer no mapa
  function handleRegionChanged(region) {
    setCurrentRegion(region);
  }

  if (!currentRegion) {
    return null;
  }

  // Realiza a troca do tipo de mapa
  function swapMapType() {
    setMapType(mapType === 'satellite' ? 'standard' : 'satellite');
  }

  return (
    <>
      <MapView
        initialRegion={currentRegion}
        mapType={mapType}
        onRegionChange={handleRegionChanged}
        style={{ flex: 1 }}>
      </MapView>

      <View style={styles.buttonView}>
        <TouchableOpacity onPress={swapMapType} style={styles.button}>
          <MaterialIcons name='swap-horiz' size={20} color='#FFF' />
        </TouchableOpacity>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  map: {
    flex: 1
  },
  button: {
    width: 50,
    height: 50,
    backgroundColor: '#888888',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    right: 0,
    elevation: 20
  },
  buttonView: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    zIndex: 5,
    flexDirection: 'row-reverse',
    display: 'flex',
  }
});