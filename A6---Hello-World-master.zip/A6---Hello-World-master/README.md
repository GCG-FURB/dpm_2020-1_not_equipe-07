# Criando projeto Hello World

> ### Instruções retiradas do site:  
> https://reactnative.dev/docs/environment-setup

### Iniciando projeto:

1. Pela equipe foi utilizado o próprio celular para rodar o aplicativo;
2. Foi necessário apenas configurar as varaiveis de ambiente do android e posteriormente rodar os comandos de criação de projeto do React Native;
3. Após isto rodado o "npm install" para instalar todas as dependecias;
4. E após isso basta rodar o comando "npx react-native run-android" e foi possível ver o aplicativo no celular.

### Depurando projeto:
1. Basta chacoalhar o dispositivo e o mesmo apresenta algumas opções, clicar em "Debug";
2. Será aberto um navegador com o código fonte da aplicação, então só basta inserir um break point no código e depurar o JavaScript.
